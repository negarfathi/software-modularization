Written by Peter O. in 2014.  In the public domain.

Public domain dedication: [http://creativecommons.org/publicdomain/zero/1.0/](http://creativecommons.org/publicdomain/zero/1.0/)
